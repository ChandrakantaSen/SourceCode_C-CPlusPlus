#include<stdio.h>
#include<conio.h>
struct node
{
int info;
struct node *link;
};
struct node *insert_end(int i,struct node *head);
struct node *common(struct node *h1,struct node *h2);
struct node *merge(struct node *h1,struct node *h2);
struct node *del_negative(struct node *head);
struct node *del(struct node *h1,struct node *t);
void display(struct node *head);
void main()
{
int a,b,c,x,u;
char ch,ch1;
struct node *start1,*m,*n;
struct node *start2;
struct node *start3;
clrscr();
start1=NULL;
start2=NULL;
printf("Enter elements in list 1:\n");
do
{
printf("Enter element:\n");
scanf("%d",&a);
start1=insert_end(a,start1);
printf("Insert more elements? y/n\n");
scanf(" %c",&ch);
}
while(ch=='y');
printf("\nElements in list 1 are:\t");
display(start1);
printf("\n");
printf("Enter elements in list 2:\n");
do
{
printf("Enter element:\n");
scanf("%d",&b);
start2=insert_end(b,start2);
printf("Insert more elements? y/n\n");
scanf(" %c",&ch);
}
while(ch=='y');
printf("\nElements in list 2 are:\t");
display(start2);
printf("\n");
do
{
printf("Enter your choice\n");
printf("1: Merge the linked lists\n");
printf("2: Print the common elements\n");
printf("3: Delete all negative elements from a list\n");
printf("4 :Split a linked list into two\n");
scanf("%d",&c);
if(c==1)
{
m=merge(start1,start2);
printf("\nMerged list is :\t");
display(m);
}
else if(c==2)
{
printf("Common elements in both linked lists are:\t");
common(start1,start2);
}
else if(c==3)
{
printf("From which list you want to delete negative elements?\n");
scanf("%d",&x);
if(x==1)
{
start1=del_negative(start1);
printf("Elements are :\t");
display(start1);
}
else
{
start2=del_negative(start2);
printf("Elements are :\t");
display(start2);
}
}
else if(c==4)
{
printf("Which list you wish to split?\n");
scanf("%d",&u);
if(u==1)
{
del_negative(start1);
}
else if(u==2)
{
del_negative(start2);
}
}
printf("\nDo you wish to continue?y/n\n");
scanf(" %c",&ch1);
}
while(ch1=='y');
getch();
}
struct node *insert_end(int i,struct node *head)
{
struct node *temp,*newptr;
newptr=(struct node *)malloc(sizeof(struct node));
newptr->info=i;
newptr->link=NULL;
if(head==NULL)
{
head=newptr;
}
else
{
temp=head;
while(temp->link!=NULL)
temp=temp->link;
temp->link=newptr;
}
return head;
}
struct node *merge(struct node *h1,struct node *h2)
{
struct node *start3,*t1,*t2,*t3,*ptr;
start3=NULL;
t1=h1;
t2=h2;
t3=start3;
while(1)
{
if(t1!=NULL)
{
ptr=(struct node *)malloc(sizeof(struct node));
ptr->info=t1->info;
ptr->link=NULL;
if(t3==NULL)
{
start3=ptr;
t3=ptr;
t1=t1->link;
}
else
{
t3->link=ptr;
t3=ptr;
t1=t1->link;
}
}
if(t2!=NULL)
{
ptr=(struct node *)malloc(sizeof(struct node));
ptr->info=t2->info;
ptr->link=NULL;
if(t3==NULL)
{
start3=ptr;
t3=ptr;
t2=t2->link;
}
else
{
t3->link=ptr;
t3=ptr;
t2=t2->link;
}
}
if(t1==NULL && t2==NULL)
{
return start3;
}
}
}
void display(struct node *head)
{
do
{
printf("%d\t",head->info);
head=head->link;
}
while(head!=NULL);
printf("\n");
}

struct node *common(struct node *h1,struct node *h2)
{
int flag=0;
struct node *t1,*t2;
t1=h1;
while(t1!=NULL)
{
t2=h2;
while(t2!=NULL)
{
if(t1->info==t2->info)
{
printf("%d\t",t1->info);
flag++;
}
t2=t2->link;
}
t1=t1->link;
}
if(flag==0)
{
printf("\nNo Elements are in common :-(\n");
}
return 0;
}

struct node *del(struct node *h1,struct node *t)
{
struct node *tmp,*ptr;
if(h1==t)
{
tmp=h1;
h1=h1->link;
free(tmp);
return h1;
}
else
{
ptr=h1;
tmp=h1;
while(tmp!=NULL)
{
if(tmp==t)
{
ptr->link=tmp->link;
free(tmp);
}
tmp=tmp->link;
}
}
return h1;
}
struct node *del_negative(struct node *head)
{
struct node *temp;
temp=NULL;
if(head->info<0)
{
head=head->link;
}
temp=head;
while(temp!=NULL)
{
if((temp->info)<0)
{
head=del(head,temp);
temp = head;
}
temp=temp->link;
}
return head;
}







