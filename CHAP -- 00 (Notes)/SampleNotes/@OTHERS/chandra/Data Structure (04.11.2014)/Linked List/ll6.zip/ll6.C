#include<stdio.h>
#include<conio.h>
typedef struct nodetype
{
int info;
struct nodetype *next;
}node;
void insertatbeg(node **head,int item)
{
node *ptr;
ptr=(node*)malloc(sizeof(node));
ptr->info=item;
if(*head==NULL)
ptr->next=NULL;
else
ptr->next=*head;
*head=ptr;
}
void insertatend(node **head, int item)
{
node *ptr, *loc;
ptr=(node*)malloc(sizeof(node));
ptr->info=item;
ptr->next=NULL;
if(*head==NULL)
*head=ptr;
else
{
loc=*head;
while (loc->next!=NULL)
loc=loc->next;
loc->next=ptr;
}
}
void printval(node *head)
{
while(head!=NULL)
{
printf("%d ",head->info);
head=head->next;
}
}
void createemptylist(node **head)
{
*head=NULL;
}
void separate(node *h1,node **h2,node **h3)
{ int item;
node *ptr;
while(h1!=NULL)
{
if((h1->info)<0)
{
item=h1->info;
insertatend(h3,item);
}
else
{
item=h1->info;
insertatend(h2,item);
}
h1=h1->next;
}
}
void main()
{
node *head1,*head2,*head3;
int elt;
clrscr();
createemptylist(&head1);
createemptylist(&head2);
createemptylist(&head3);
printf("\nEnter elements of the first list:press -1111 to exit:");
do
{
scanf("%d",&elt);
if(elt==-1111)
break;
insertatbeg(&head1,elt);
}while(1);
printf("\nThe original list:");
printval(head1);
separate(head1,&head2,&head3);
printf("\nThe positive list is:");
printval(head2);
printf("\nThe negative list is:");
printval(head3);
getch();
}
