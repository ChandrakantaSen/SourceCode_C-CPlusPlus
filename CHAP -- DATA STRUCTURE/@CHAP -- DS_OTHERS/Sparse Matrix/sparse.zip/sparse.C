#include<stdio.h>
#include<conio.h>
#include<malloc.h>
struct columnNode
{
int col;
float element;
struct columnNode *link;
};
struct rowNode
{
int row;
struct rowNode *next;
struct columnNode *first;
};
struct headerNode
{
int nrow;
int ncol;
int num;
struct rowNode *head;
};
void store_element(struct headerNode *sparse,int i,int j,int element);
int returnElement(struct headerNode *sparse,int i,int j);
void display(struct headerNode *ptr);
void main()
{
int m,n,i,j,a,u,x,y;
struct headerNode *sparse;
clrscr();
printf("Enter the number of rows\n");
scanf("%d",&m);
printf("Enter the number of columns\n");
scanf("%d",&n);
sparse=(struct headerNode *)malloc(sizeof(struct headerNode));
sparse->nrow=m;
sparse->ncol=n;
sparse->num=0;
sparse->head=NULL;
printf("Enter number of Non-zero items:\n");
scanf("%d",&a);
for(i=1;i<=a;i++)
{
printf("Enter non-zero element no. %d\n",i);
scanf("%d",&u);
printf("Enter its row no.\n");
scanf("%d",&x);
printf("Enter its column no.\n");
scanf("%d",&y);
store_element(sparse,x,y,u);
}
printf("Sparse Matrix is\n");
display(sparse);
getch();
}
void store_element(struct headerNode *sparse,int i,int j,int element)
{
struct rowNode *rptr,*rtemp,*rtmp;
struct columnNode *cptr,*ctemp,*ctmp;
sparse->num++;
cptr=(struct columnNode *)malloc(sizeof(struct columnNode));
rptr=(struct rowNode *)malloc(sizeof(struct rowNode));
cptr->col=j;
cptr->element=element;
if(sparse->head==NULL)
{
sparse->head=rptr;
rptr->next=NULL;
rptr->row=i;
rptr->first=cptr;
cptr->link=NULL;
return;
}
rtemp=NULL;
rtmp=sparse->head;
while((rtmp!=NULL && rtmp->row<i))
{
rtemp=rtmp;
rtmp=rtmp->next;
}
if(rtmp->row==i)
{
ctemp=NULL;
ctmp=rtmp->first;
while((ctmp!=NULL && ctmp->col<j))
{
ctemp=ctmp;
ctmp=ctmp->link;
}
if(ctemp==NULL)
{
cptr->link=rtmp->first;
rtmp->first=cptr;
}
else
{
cptr->link=ctmp;
ctemp->link=cptr;
}
return;
}
else if(rtmp==NULL)
{
rptr=(struct rowNode *)malloc(sizeof(struct rowNode));
rtemp->next=rptr;
rptr->next=NULL;
rptr->row=i;
rptr->first=cptr;
cptr->link=NULL;
return;
}
else
{
rptr=(struct rowNode *)malloc(sizeof(struct rowNode));
rptr->row=i;
rptr->next=rtmp;
rtemp->next=rptr;
rptr->first=cptr;
cptr->link=NULL;
}
}
int returnElement(struct headerNode *sparse,int i,int j)
{
struct rowNode *rptr;
struct columnNode *cptr;
rptr=sparse->head;
while((rptr!=NULL) && (rptr->row<i))
rptr=rptr->next;
if(rptr==NULL)
return 0;
else if(rptr->row>i)
return 0;
else if(rptr->row==i)
{
cptr=rptr->first;
while((cptr!=NULL && cptr->col<j))
cptr=cptr->link;
if(cptr==NULL)
return 0;
else if(cptr->col>j)
return 0;
else if(cptr->col==j)
return cptr->element;
}
}
void display(struct headerNode *ptr)
{
int i,j,element;
for(i=1;i<=ptr->nrow;i++)
{
for(j=1;j<=ptr->ncol;j++)
{
element=returnElement(ptr,i,j);
printf("%4d",element);
}
printf("\n");
}
}