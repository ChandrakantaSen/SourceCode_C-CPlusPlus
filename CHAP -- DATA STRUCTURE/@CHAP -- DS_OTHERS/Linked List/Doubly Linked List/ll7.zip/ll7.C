#include<stdio.h>
#include<conio.h>
struct node
{
struct node *prev;
int info;
struct node *next;
};
struct node *start,*tail,*start2,*tail2,*tail3,*start3;
struct node *create_new_node(int i);
void insertend(struct node *n);
void add_before(struct node *p);
void add_after(struct node *o);
void del_before(int element);
void del_after(int ele);
void del(int elem);
void insertbeg(struct node *m);
void split(struct node *head);
void display(struct node *x);
int count(struct node *c);
void main()
{
int info,a,c;
struct node *np;
char ch;
start=NULL;
tail=NULL;
clrscr();
do
{
printf("ENTER YOUR CHOICE:\n");
printf("Enter 1 to insert at begining\n");
printf("Enter 2 to insert before a given element\n");
printf("Enter 3 to after a given element\n");
printf("Enter 4 to insert at end\n");
printf("Enter 5 to delete after a given element\n");
printf("Enter 6 to delete before a given element\n");
printf("Enter 7 to delete a paarticular element\n");
printf("Enter 8 to split the current linked list into 2 new\n");
scanf("%d",&a);
if(a==1)
{
printf("Enter the new element\n");
scanf("%d",&info);
np=create_new_node(info);
insertbeg(np);
}
else if(a==2)
{
printf("Enter the new element\n");
scanf("%d",&info);
np=create_new_node(info);
add_before(np);
}
else if(a==3)
{
printf("Enter the new element\n");
scanf("%d",&info);
np=create_new_node(info);
add_after(np);
}
else if(a==4)
{
printf("Enter the new element\n");
scanf("%d",&info);
np=create_new_node(info);
insertend(np);
}
else if(a==5)
{
printf("Enter the element whose next element is to be deleted\n");
scanf("%d",&info);
del_after(info);
}
else if(a==6)
{
printf("Enter the element whose previous element is to be deleted\n");
scanf("%d",&info);
del_before(info);
}
else if(a==7)
{
printf("Enter the element to be deleted\n");
scanf("%d",&info);
del(info);
}
else if(a==8)
{
split(start);
printf("The two linked lists are\n");
printf("Even:\t");
display(start2);
printf("Odd:\t");
display(start3);
}
display(start);
c=count(start);
printf("The number of nodes are %d\n",c);
printf("\nDo you want to proceed? y/n\n");
scanf(" %c",&ch);
}
while(ch=='y');
getch();
}
/*CREATION OF NEW NODE*/
struct node *create_new_node(int i)
{
struct node *newptr;
newptr=(struct node *)malloc(sizeof(struct node));
newptr->info=i;
newptr->next=NULL;
newptr->prev=NULL;
return newptr;
}
/*INSERTION AT BEGINING*/
void insertbeg(struct node *m)
{
if(start==NULL)
{
start=m;
tail=m;
}
else
{
m->prev=NULL;
m->next=start;
start->prev=m;
start=m;
}
}
/*INSERTION AT END*/
void insertend(struct node *n)
{
if(start==NULL)
{
start=n;
tail=n;
}
else
{
n->next=NULL;
n->prev=tail;
tail->next=n;
tail=n;
}
}
/*INSERTION BEFORE A GIVEN ELEMENT*/
void add_before(struct node *p)
{
int value;
struct node *temp,*tmp;
temp=start;
printf("Enter the number before which new element has to be inserted:\n");
scanf("%d",&value);
while(temp!=NULL)
{
if(temp->info==value)
{
tmp=temp;
}
temp=temp->next;
}
if(tmp->prev==NULL)
{
p->prev=NULL;
tmp->prev=p;
p->next=start;
start=p;
}
else
{
p->next=tmp;
p->prev=tmp->prev;
tmp->prev->next=p;
tmp->prev=p;
}
}
/*INSERTION AFTER A GIVEN ELEMENT*/
void add_after(struct node *o)
{
int value;
struct node *temp;
temp=start;
printf("Enter the number after which new element has to be inserted:\n");
scanf("%d",&value);
while(temp!=NULL)
{
if(temp->info==value)
{
o->prev=temp;
o->next=temp->next;
temp->next->prev=o;
temp->next=o;
}
temp=temp->next;
}
}
/*DELETION BEFORE A GIVEN ELEMENT*/
void del_before(int element)
{
struct node *temp,*loc,*tmp;
temp=start;
tmp=start;
while(temp!=NULL)
{
if(temp->info==element)
{
loc=temp;
}
temp=temp->next;
}
if(loc->prev->prev==NULL)
{
tmp=loc->prev;
loc->prev=NULL;
start=loc;
free(tmp);
}
else
{
tmp=loc->prev;
loc->prev=tmp->prev;
tmp->prev->next=loc;
free(tmp);
}
}
/*DELETION AFTER A GIVEN ELEMENT*/
void del_after(int ele)
{
struct node *temp,*loc,*tmp;
temp=start;
tmp=start;
while(temp!=NULL)
{
if(temp->info==ele)
{
loc=temp;
}
temp=temp->next;
}
if(loc->next->next==NULL)
{
tmp=loc->next;
loc->next=NULL;
tail=loc;
free(tmp);
}
else
{
tmp=loc->next;
loc->next=tmp->next;
tmp->next->prev=loc;
free(tmp);
}
}
/*DELETE*/
void del(int elem)
{
struct node *temp,*ptr,*loc;
temp=start;
while(temp!=NULL)
{
if(temp->info==elem)
{
loc=temp;
}
temp=temp->next;
}
if(loc->prev==NULL)
{
ptr=loc;
loc->next->prev=NULL;
start=loc->next;
free(ptr);
}
else if(loc->next==NULL)
{
ptr=loc;
loc->prev->next=NULL;
tail=loc->prev;
free(ptr);
}
else
{
ptr=loc;
loc->prev->next=ptr->next;
loc->next->prev=ptr->prev;
free(ptr);
}
}
void split(struct node *head)
{
struct node *temp,*newptr,*nptr;
start2=NULL;
start3=NULL;
tail2=NULL;
tail3=NULL;
temp=head;
while(temp!=NULL)
{
if((temp->info)%2==0)
{
newptr=(struct node *)malloc(sizeof(struct node));
newptr->info=temp->info;
newptr->next=NULL;
newptr->prev=NULL;
if(start2==NULL)
{
start2=newptr;
tail2=newptr;
}
else
{
newptr->next=NULL;
newptr->prev=tail2;
tail2->next=newptr;
tail2=newptr;
}
}
else
{
nptr=(struct node *)malloc(sizeof(struct node));
nptr->info=temp->info;
nptr->next=NULL;
nptr->prev=NULL;
if(start3==NULL)
{
start3=nptr;
tail3=nptr;
}
else
{
nptr->next=NULL;
nptr->prev=tail3;
tail3->next=nptr;
tail3=nptr;
}
}
temp=temp->next;
}
}
/*DISPLAY*/
void display(struct node *x)
{
printf("\nCurrent linked list is:\t");
do
{
printf("%d\t",x->info);
x=x->next;
}
while(x!=NULL);
printf("\n");
}
/*COUNT THE NO. OF NODES*/
int count(struct node *c)
{
int co=0;
do
{
co++;
c=c->next;
}
while(c!=NULL);
return co;
}
























